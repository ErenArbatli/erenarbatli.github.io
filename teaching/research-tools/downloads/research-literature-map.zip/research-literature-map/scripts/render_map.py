#!/usr/bin/env python3
"""Validate literature-map provenance fields and render portable research outputs."""

import argparse
import csv
import datetime
import io
import json
from pathlib import Path
import re
import sys
from urllib.parse import quote, urlsplit


FIELDS = ("question", "mechanism", "design", "result", "scope", "connection", "difference")
BASES = {"source", "interpretation", "not_checked", "not_reported"}
ROLES = {"question", "mechanism", "method", "alternative_explanation", "background", "uncertain"}
ROUTES = {"concept", "economics", "backward", "forward", "recent", "novelty", "user_seed"}
LABELS = {"source": "Authors state", "interpretation": "Interpretation", "not_checked": "Not checked", "not_reported": "Not reported in inspected material"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def text_value(value):
    return isinstance(value, str) and bool(value.strip())


def strings(value):
    return isinstance(value, list) and all(text_value(item) for item in value)


def link_value(value):
    if not text_value(value) or any(ord(c) < 32 for c in value):
        return False
    return value.startswith("/") or (urlsplit(value).scheme in {"http", "https"} and bool(urlsplit(value).netloc))


def valid_date(value):
    require(isinstance(value, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", value), "Date must be YYYY-MM-DD")
    datetime.date.fromisoformat(value)


def validate(data):
    require(isinstance(data, dict), "The root must be an object")
    project = data.get("project")
    require(isinstance(project, dict), "Missing project object")
    for key in ("title", "description", "search_mode"):
        require(text_value(project.get(key)), f"project.{key} must be nonempty")
    valid_date(project.get("date"))
    require(strings(project.get("limitations")), "project.limitations must be a string list")
    for key in ("papers", "searches", "candidates", "connections", "reading_tasks"):
        require(isinstance(data.get(key), list), f"{key} must be a list")

    papers, evidence = {}, {}
    for paper in data["papers"]:
        require(isinstance(paper, dict), "Paper must be an object")
        pid = paper.get("id")
        require(text_value(pid) and re.fullmatch(r"P[0-9]+", pid), "Paper IDs must be P plus digits")
        require(pid not in papers, f"Duplicate paper ID: {pid}")
        papers[pid] = paper
        for key in ("title", "version"):
            require(text_value(paper.get(key)), f"{pid}: missing {key}")
        require(strings(paper.get("authors")) and paper["authors"], f"{pid}: missing authors")
        require(type(paper.get("year")) is int and 1500 <= paper["year"] <= 2200, f"{pid}: invalid year")
        require(paper.get("identity_checked") is True, f"{pid}: unchecked identities belong in candidates")
        for key in ("identity_url", "source_url"):
            require(link_value(paper.get(key)), f"{pid}: invalid {key}")
        require(type(paper.get("student_checked")) is bool, f"{pid}: student_checked must be boolean")
        require(paper.get("access") in {"metadata_only", "abstract_only", "full_text"}, f"{pid}: invalid access")
        require(strings(paper.get("read_sections")), f"{pid}: read_sections must be a string list")
        require(paper["access"] == "metadata_only" or paper["read_sections"], f"{pid}: specify actual sections read")
        require(strings(paper.get("roles")) and paper["roles"] and set(paper["roles"]) <= ROLES, f"{pid}: invalid roles")
        require(paper.get("priority") in {"must_read", "useful", "background", "uncertain"}, f"{pid}: invalid priority")
        require(isinstance(paper.get("evidence"), list), f"{pid}: missing evidence list")
        local_ids = set()
        for item in paper["evidence"]:
            require(isinstance(item, dict), f"{pid}: evidence must be objects")
            eid = item.get("id")
            require(text_value(eid) and re.fullmatch(r"E[0-9]+", eid), f"{pid}: invalid evidence ID")
            require(eid not in evidence, f"Duplicate evidence ID: {eid}")
            require(text_value(item.get("location")) and text_value(item.get("note")), f"{eid}: missing locator/note")
            if paper["access"] == "abstract_only":
                require(item["location"].lower().startswith("abstract"), f"{eid}: abstract-only source cannot support an unseen locator")
            evidence[eid] = (pid, item)
            local_ids.add(eid)
        require(paper["access"] != "metadata_only" or not local_ids, f"{pid}: metadata-only rows cannot contain textual evidence")
        claims = paper.get("claims")
        require(isinstance(claims, dict) and all(key in claims for key in FIELDS), f"{pid}: seven claim fields are required")
        for key in FIELDS:
            claim = claims[key]
            require(isinstance(claim, dict), f"{pid}.{key}: claim must be an object")
            require(text_value(claim.get("text")) and claim.get("basis") in BASES, f"{pid}.{key}: invalid text/basis")
            refs = claim.get("evidence_ids")
            require(strings(refs) and set(refs) <= local_ids, f"{pid}.{key}: unknown or other-paper evidence")
            if claim["basis"] in {"source", "not_reported"}:
                require(bool(refs), f"{pid}.{key}: source/absence claims need supporting locations")
            if claim["basis"] == "not_checked":
                require(not refs, f"{pid}.{key}: not_checked cannot cite inspected evidence")

    for search in data["searches"]:
        require(isinstance(search, dict), "Search must be an object")
        valid_date(search.get("date"))
        for key in ("tool", "query", "decision"):
            require(text_value(search.get(key)), f"Search missing {key}")
        require(search.get("route") in ROUTES, "Invalid search route")
        for key in ("seed_ids", "paper_ids"):
            require(strings(search.get(key)) and set(search[key]) <= set(papers), f"Search has unknown {key}")
    for candidate in data["candidates"]:
        require(isinstance(candidate, dict), "Candidate must be an object")
        require(text_value(candidate.get("title")) and text_value(candidate.get("reason")), "Candidate missing title/reason")
        require(candidate.get("disposition") in {"included", "deferred", "excluded", "unverified"}, "Invalid candidate disposition")
        require(candidate.get("url") == "" or link_value(candidate.get("url")), "Invalid candidate URL")
    for edge in data["connections"]:
        require(isinstance(edge, dict), "Connection must be an object")
        require(edge.get("from") in papers and edge.get("to") in papers and edge["from"] != edge["to"], "Invalid connection endpoints")
        require(edge.get("kind") in {"citation", "inferred"} and text_value(edge.get("description")), "Invalid connection kind/description")
        refs = edge.get("evidence_ids")
        require(strings(refs) and refs and set(refs) <= set(evidence), "Connection needs valid evidence IDs")
        owners = {evidence[eid][0] for eid in refs}
        endpoints = {edge["from"], edge["to"]}
        require(owners <= endpoints, "Connection evidence must come from its endpoints")
        if edge["kind"] == "citation":
            require(edge["from"] in owners, "Citation needs evidence from the citing paper")
        else:
            require(owners == endpoints, "Inferred connection needs evidence from both papers")
    for task in data["reading_tasks"]:
        require(isinstance(task, dict) and task.get("paper_id") in papers, "Reading task needs a known paper")
        require(all(text_value(task.get(k)) for k in ("sections", "question", "decision")), "Reading task missing sections/question/decision")
    return data


def md(value):
    value = str(value).replace("\\", "\\\\")
    for char in "[]<>|":
        value = value.replace(char, "\\" + char)
    return value.replace("\r", "").replace("\n", "<br>")


def link(label, destination):
    return f"[{md(label)}]({quote(destination, safe=':/?=&%#@+~,;')})"


def refs(claim):
    return " ".join(f"[{eid}](#evidence-{eid.lower()})" for eid in claim["evidence_ids"])


def cell(claim):
    return f"**{LABELS[claim['basis']]}:** {md(claim['text'])} {refs(claim)}".strip()


def csv_safe(value):
    value = str(value)
    return "'" + value if value.lstrip().startswith(("=", "+", "-", "@")) else value


def render(data):
    validate(data)
    project = data["project"]
    lines = [f"# Literature Map: {md(project['title'])}", "", f"Date: {project['date']}", "", md(project["description"]), "", f"Search mode: {md(project['search_mode'])}", "", "Identity, text inspection and student verification are separate. This is not a novelty or completeness certificate.", "", "## Comparison Matrix", "", "| Paper / version | Question / mechanism | Design / assumptions | Result / scope | Project connection | Potential consequential difference | Evidence / reading status |", "| --- | --- | --- | --- | --- | --- | --- |"]
    csv_buffer = io.StringIO(newline="")
    writer = csv.writer(csv_buffer)
    header = ["paper_id", "title", "authors", "year", "version", "source_url", "identity_url", "roles", "priority", "access", "sections_inspected", "student_checked"]
    for field in FIELDS:
        header.extend([field, field + "_basis", field + "_evidence"])
    writer.writerow(header)
    if not data["papers"]:
        lines.extend(["", "No identity-checked paper comparisons are available. Candidate leads and proposed searches are not source-backed comparisons; see the search log and any accompanying query pack.", ""])
    for paper in data["papers"]:
        claims = paper["claims"]
        status = f"{md(paper['access'])}; read: {md('; '.join(paper['read_sections']) or 'metadata only')}; student checked: {str(paper['student_checked']).lower()}"
        row = [link(paper["id"] + ": " + paper["title"], paper["source_url"]) + "<br>" + md(paper["version"]), cell(claims["question"]) + "<br>" + cell(claims["mechanism"]), cell(claims["design"]), cell(claims["result"]) + "<br>" + cell(claims["scope"]), cell(claims["connection"]), cell(claims["difference"]), status]
        lines.append("| " + " | ".join(row) + " |")
        csv_row = [paper["id"], paper["title"], "; ".join(paper["authors"]), paper["year"], paper["version"], paper["source_url"], paper["identity_url"], "; ".join(paper["roles"]), paper["priority"], paper["access"], "; ".join(paper["read_sections"]), str(paper["student_checked"]).lower()]
        evidence_by_id = {e["id"]: e for e in paper["evidence"]}
        for field in FIELDS:
            claim = claims[field]
            locations = "; ".join(f"{eid}: {evidence_by_id[eid]['location']} | {paper['source_url']}" for eid in claim["evidence_ids"])
            csv_row.extend([claim["text"], LABELS[claim["basis"]], locations])
        writer.writerow([csv_safe(value) for value in csv_row])

    lines.extend(["", "## Evidence Cards", ""])
    for paper in data["papers"]:
        lines.extend([f"### {paper['id']}: {md(paper['title'])}", "", f"{md('; '.join(paper['authors']))} ({paper['year']}). {md(paper['version'])}.", "", link("Identity record", paper["identity_url"]) + " | " + link("Inspected source", paper["source_url"]), "", f"Roles: {md(', '.join(paper['roles']))}. Priority: {md(paper['priority'])}. Access: {paper['access']}.", "", f"Sections inspected: {md('; '.join(paper['read_sections']) or 'metadata only')}. Student checked: {str(paper['student_checked']).lower()}.", ""])
        if paper.get("version_note"):
            lines.extend([f"Version note: {md(paper['version_note'])}", ""])
        for item in paper["evidence"]:
            lines.extend([f"<a id=\"evidence-{item['id'].lower()}\"></a>", "", f"- **{item['id']}** {link(item['location'], paper['source_url'])}: {md(item['note'])}", ""])
        lines.extend([""] + [f"- **{field.title()}:** {cell(paper['claims'][field])}" for field in FIELDS] + [""])

    lines.extend(["## Connections", ""])
    for edge in data["connections"]:
        support = " ".join(f"[{eid}](#evidence-{eid.lower()})" for eid in edge["evidence_ids"])
        label = "Observed citation relationship" if edge["kind"] == "citation" else "Inferred intellectual connection"
        lines.append(f"- {edge['from']} -> {edge['to']} ({label}): {md(edge['description'])} {support}")
    lines.extend(["", "## Priority Reading Tasks", ""])
    for i, task in enumerate(data["reading_tasks"], 1):
        lines.append(f"{i}. **{task['paper_id']}** Read: {md(task['sections'])}. Question: {md(task['question'])} Decision: {md(task['decision'])}")
    lines.extend(["", "## Coverage And Limits", ""] + ["- " + md(value) for value in project["limitations"]])
    log = [f"# Search Log: {md(project['title'])}", "", f"Search mode: {md(project['search_mode'])}", ""]
    for i, search in enumerate(data["searches"], 1):
        log.extend([f"## Search {i}", "", f"- Date: {search['date']}", f"- Tool: {md(search['tool'])}", f"- Route: {search['route']}", f"- Exact query / source section: {md(search['query'])}", f"- Seeds: {md(', '.join(search['seed_ids']) or 'none')}", f"- Matrix papers found: {md(', '.join(search['paper_ids']) or 'none; see candidate ledger')}", f"- Follow-up decision: {md(search['decision'])}", ""])
    if not data["searches"]:
        log.extend(["No live searches recorded. Do not interpret this as a search of any database.", ""])
    log.extend(["## Candidate Decisions", ""])
    for candidate in data["candidates"]:
        title = link(candidate["title"], candidate["url"]) if candidate["url"] else md(candidate["title"])
        log.append(f"- **{candidate['disposition']}** {title}: {md(candidate['reason'])}")
    log.extend(["", "## Unavailable Routes And Other Limits", ""] + ["- " + md(value) for value in project["limitations"]])
    return {"literature_map.md": "\n".join(lines) + "\n", "comparison_matrix.csv": csv_buffer.getvalue(), "search_log.md": "\n".join(log) + "\n"}


def write_outputs(outputs, directory):
    directory = Path(directory)
    require(not any((directory / name).exists() for name in outputs), "Output file already exists; choose a new directory to preserve annotations")
    directory.mkdir(parents=True, exist_ok=True)
    for name, content in outputs.items():
        with (directory / name).open("x", encoding="utf-8-sig" if name.endswith(".csv") else "utf-8", newline="") as handle:
            handle.write(content)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--check", action="store_true", help="Validate records without writing files")
    args = parser.parse_args()
    if not args.check and args.out is None:
        parser.error("Use --check or supply --out")
    try:
        with args.input.open(encoding="utf-8-sig") as handle:
            data = json.load(handle)
        outputs = render(data)
        if not args.check:
            write_outputs(outputs, args.out)
        print(f"Validated {len(data['papers'])} paper records; factual accuracy still requires source reading.")
    except (ValueError, OSError, TypeError, KeyError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
