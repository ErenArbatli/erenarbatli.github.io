"""Synthetic fixtures test record integrity, not claims about actual papers."""

import copy
import csv
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("render_map", ROOT / "scripts" / "render_map.py")
renderer = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(renderer)


def fixture():
    data = json.loads((ROOT / "assets" / "starter.json").read_text())
    data["project"]["title"] = "Synthetic test project"
    data["papers"] = [{
        "id": "P01", "title": "Synthetic test source", "authors": ["Fixture Author"],
        "year": 2020, "version": "Test fixture, not a scholarly source",
        "identity_url": "https://example.org/record", "source_url": "https://example.org/source.pdf",
        "identity_checked": True, "student_checked": False, "access": "full_text",
        "read_sections": ["Introduction"], "roles": ["question"], "priority": "must_read",
        "evidence": [{"id": "E01", "location": "Introduction, p. 1", "note": "Synthetic evidence."}],
        "claims": {field: {"text": "Unknown.", "basis": "not_checked", "evidence_ids": []} for field in renderer.FIELDS}
    }]
    data["papers"][0]["claims"]["question"] = {"text": "A synthetic question.", "basis": "source", "evidence_ids": ["E01"]}
    return data


class RecordTests(unittest.TestCase):
    def setUp(self):
        self.data = fixture()
        self.paper = self.data["papers"][0]

    def test_valid_record_renders_explicit_status_and_links(self):
        outputs = renderer.render(self.data)
        self.assertIn("student checked: false", outputs["literature_map.md"])
        self.assertIn("[E01](#evidence-e01)", outputs["literature_map.md"])
        self.assertIn('id="evidence-e01"', outputs["literature_map.md"])
        rows = list(csv.DictReader(io.StringIO(outputs["comparison_matrix.csv"])))
        self.assertEqual(len(rows), 1)
        self.assertIn("Introduction, p. 1 | https://example.org/source.pdf", rows[0]["question_evidence"])
        self.assertEqual(rows[0]["student_checked"], "false")

    def test_source_claim_requires_evidence(self):
        self.paper["claims"]["question"]["evidence_ids"] = []
        with self.assertRaises(ValueError):
            renderer.validate(self.data)

    def test_unchecked_is_not_absence_from_inspected_material(self):
        self.paper["claims"]["design"]["basis"] = "not_reported"
        with self.assertRaises(ValueError):
            renderer.validate(self.data)

    def test_abstract_cannot_cite_unseen_design_section(self):
        self.paper["access"] = "abstract_only"
        self.paper["read_sections"] = ["Abstract"]
        with self.assertRaises(ValueError):
            renderer.validate(self.data)
        self.paper["evidence"][0]["location"] = "Abstract"
        renderer.validate(self.data)

    def test_metadata_cannot_include_textual_evidence(self):
        self.paper["access"] = "metadata_only"
        with self.assertRaises(ValueError):
            renderer.validate(self.data)

    def test_unresolved_identity_stays_out_of_matrix(self):
        self.paper["identity_checked"] = False
        with self.assertRaises(ValueError):
            renderer.validate(self.data)

    def test_missing_human_status_is_not_inferred(self):
        del self.paper["student_checked"]
        with self.assertRaises(ValueError):
            renderer.validate(self.data)

    def test_claims_cannot_borrow_other_paper_evidence(self):
        self.paper["claims"]["question"]["evidence_ids"] = ["E02"]
        with self.assertRaises(ValueError):
            renderer.validate(self.data)

    def test_duplicate_ids_rejected(self):
        self.data["papers"].append(copy.deepcopy(self.paper))
        with self.assertRaises(ValueError):
            renderer.validate(self.data)

    def add_second_paper(self):
        other = copy.deepcopy(self.paper)
        other["id"] = "P02"
        other["evidence"][0]["id"] = "E02"
        other["claims"]["question"]["evidence_ids"] = ["E02"]
        self.data["papers"].append(other)

    def test_inferred_connection_needs_both_sources(self):
        self.add_second_paper()
        self.data["connections"] = [{"from": "P02", "to": "P01", "kind": "inferred", "description": "Potential shared mechanism.", "evidence_ids": ["E02"]}]
        with self.assertRaises(ValueError):
            renderer.validate(self.data)
        self.data["connections"][0]["evidence_ids"].append("E01")
        renderer.validate(self.data)

    def test_citation_requires_citing_paper_evidence(self):
        self.add_second_paper()
        self.data["connections"] = [{"from": "P02", "to": "P01", "kind": "citation", "description": "Observed citation.", "evidence_ids": ["E01"]}]
        with self.assertRaises(ValueError):
            renderer.validate(self.data)

    def test_unsafe_url_rejected(self):
        self.paper["source_url"] = "javascript:alert(1)"
        with self.assertRaises(ValueError):
            renderer.validate(self.data)

    def test_csv_formula_cells_are_escaped(self):
        self.paper["title"] = "=1+1"
        outputs = renderer.render(self.data)
        row = next(csv.DictReader(io.StringIO(outputs["comparison_matrix.csv"])))
        self.assertEqual(row["title"], "'=1+1")
        self.assertEqual(renderer.csv_safe("  @SUM(A1)"), "'  @SUM(A1)")

    def test_markdown_table_pipes_do_not_create_columns(self):
        self.paper["claims"]["question"]["text"] = "A | B\nC"
        self.assertIn("A \\| B<br>C", renderer.render(self.data)["literature_map.md"])

    def test_search_cannot_claim_unknown_matrix_papers(self):
        self.data["searches"] = [{"date": "2026-11-08", "tool": "Synthetic", "route": "concept", "query": "Synthetic", "seed_ids": [], "paper_ids": ["P99"], "decision": "Synthetic"}]
        with self.assertRaises(ValueError):
            renderer.validate(self.data)

    def test_existing_notes_are_never_overwritten(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "search_log.md"
            path.write_text("Student annotations")
            with self.assertRaises(ValueError):
                renderer.write_outputs(renderer.render(self.data), temp)
            self.assertEqual(path.read_text(), "Student annotations")
            self.assertFalse((Path(temp) / "literature_map.md").exists())

    def test_empty_starter_and_csv_encoding(self):
        data = json.loads((ROOT / "assets" / "starter.json").read_text())
        outputs = renderer.render(data)
        with tempfile.TemporaryDirectory() as temp:
            renderer.write_outputs(outputs, temp)
            self.assertTrue((Path(temp) / "comparison_matrix.csv").read_bytes().startswith(b"\xef\xbb\xbf"))

    def test_offline_leads_do_not_become_verified_comparisons(self):
        data = json.loads((ROOT / "assets" / "starter.json").read_text())
        data["project"]["search_mode"] = "Offline; no papers supplied or sources inspected"
        data["candidates"] = [{"title": "Unverified remembered lead", "url": "", "disposition": "unverified", "reason": "Identity and text not checked; verify before reading/citing."}]
        outputs = renderer.render(data)
        self.assertIn("No identity-checked paper comparisons", outputs["literature_map.md"])
        self.assertIn("**unverified** Unverified remembered lead", outputs["search_log.md"])
        self.assertEqual(list(csv.DictReader(io.StringIO(outputs["comparison_matrix.csv"]))), [])


if __name__ == "__main__":
    unittest.main()
