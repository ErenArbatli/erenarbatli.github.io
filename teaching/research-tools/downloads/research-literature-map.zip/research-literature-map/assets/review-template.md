# Literature Map: [Project Title]

## Project And Search Scope

Preserve the student's source description/file reference in `project_brief.md`. Summarise the question, mechanism, design/model, proposed contribution and uncertainty. Label assistant interpretations and missing details. Record the search date, actual tool capabilities, budget and any privacy restrictions.

## Comparison Matrix

Use the renderer when structured records are available. Otherwise provide this compact table and evidence cards below it. A shorter matrix with honest unknowns is preferable to unverified rows.

| Paper / version | Question / mechanism | Design / assumptions | Result / scope | Connection to project | Potential consequential difference | Evidence / reading status |
| --- | --- | --- | --- | --- | --- | --- |
| Link to inspected source | Source claim or unknown | Source claim or unknown | Include conditions | Label interpretation | Change -> possible inference -> why it matters | Section/page/table/proposition; actual text inspected; student check |

## Evidence Cards

For each paper: exact citation and version; primary identity record; inspected text URL; sections actually read; source-ID/locator/paraphrase; unknowns; comparison interpretation; next reading question. Do not include copyrighted PDFs in a shareable bundle without permission.

## How The Papers Connect

List a few labelled edges, specifying observed citation links versus inferred intellectual connections and their supporting evidence.

## Three Priority Readings

| Paper | Read these sections | Resolve this question | Decision this could change |
| --- | --- | --- | --- |

## Provisional Contribution Memo

1. Closest predecessor(s) and what they establish, with evidence links.
2. Proposed change and the new inference/result it might enable.
3. Why that difference would be economically meaningful.
4. AI-assisted provisional wording, if requested, and the evidence gaps preventing a stronger claim.
5. Strongest closed-corpus objection; separate missing-predecessor search outcome.
6. Student reading/writing task, one supervision question and one next research action.

## Coverage And Limits

State actual databases/routes used, unavailable sources, abstract-only comparisons, unchecked proofs/design details and unresolved version issues. No search-completeness or novelty guarantee. Keep actual searches and inclusion/exclusion decisions in `search_log.md`.
