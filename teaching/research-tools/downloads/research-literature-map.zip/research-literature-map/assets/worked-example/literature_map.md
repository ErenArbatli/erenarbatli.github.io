# Literature Map: Worked example: refugee inflows, wages and comparison design

Date: 2026-11-08

Hypothetical early-stage project; no setting, data or new result specified. This small demonstration illustrates source-linked comparison and honest access limits, not a current literature review.

Search mode: Ordinary web search with concept-led follow-ups and primary-source opens; no vector index or authenticated database search

Identity, text inspection and student verification are separate. This is not a novelty or completeness certificate.

## Comparison Matrix

| Paper / version | Question / mechanism | Design / assumptions | Result / scope | Project connection | Potential consequential difference | Evidence / reading status |
| --- | --- | --- | --- | --- | --- | --- |
| [P01: The Impact of the Mariel Boatlift on the Miami Labor Market](https://davidcard.berkeley.edu/papers/mariel-impact.pdf)<br>Industrial and Labor Relations Review 43(2), 245-257; author-hosted published copy | **Authors state:** Mariel's effect on Miami labour-market outcomes. [E01](#evidence-e01)<br>**Not checked:** Mechanism evidence not examined. | **Authors state:** CPS comparisons across time and cities; assumptions need closer reading. [E02](#evidence-e02) [E03](#evidence-e03) | **Authors state:** Reports little adverse effect on the studied outcomes. [E01](#evidence-e01)<br>**Authors state:** Miami; less-skilled workers. [E01](#evidence-e01) | **Interpretation:** Direct question/design predecessor. [E01](#evidence-e01) [E03](#evidence-e03) | **Interpretation:** A new setting needs a meaningful boundary condition, not geography alone. [E01](#evidence-e01) | full_text; read: Title and abstract, printed p. 245 (PDF p. 2); Opening discussion, printed pp. 245-246; Comparison-city selection paragraph, printed p. 249; student checked: false |
| [P02: The Wage Impact of the Marielitos: A Reappraisal](https://journals.sagepub.com/doi/10.1177/0019793917692945)<br>ILR Review 70(5); published article abstract | **Authors state:** Wage impact for workers matching the inflow's low schooling. [E04](#evidence-e04)<br>**Not checked:** Detailed mechanism tests not inspected. | **Not checked:** Detailed design and sample restrictions not inspected. | **Authors state:** Reports a 10-30% wage decline. [E04](#evidence-e04)<br>**Authors state:** Miami high-school dropouts; further restrictions not checked. [E04](#evidence-e04) | **Interpretation:** A competing reported finding requiring comparable estimands. [E04](#evidence-e04) | **Interpretation:** Check target populations before treating estimates as contradictory. [E04](#evidence-e04) | abstract_only; read: Publisher abstract; student checked: false |
| [P03: The Labor Market Effects of a Refugee Wave: Synthetic Control Method Meets the Mariel Boatlift](https://giovanniperi.ucdavis.edu/uploads/5/6/8/2/56826033/mariel_jun2_app.pdf)<br>Author-hosted draft dated June 2, 2017 | **Authors state:** Reassess Mariel labour-market effects. [E05](#evidence-e05)<br>**Not checked:** Mechanism identification not checked. | **Authors state:** Synthetic control motivated by comparison selection and inference concerns. [E06](#evidence-e06) | **Authors state:** Reports no significant wage difference for non-Cuban dropouts. [E05](#evidence-e05)<br>**Authors state:** Mariel; non-Cuban high-school dropouts. [E05](#evidence-e05) | **Interpretation:** A prior methodological revisit, not a blank slate. [E06](#evidence-e06) | **Interpretation:** Using synthetic control alone does not establish an addition. [E06](#evidence-e06) | full_text; read: Title and abstract, p. 1; Introduction, pp. 2-3; student checked: false |

## Evidence Cards

### P01: The Impact of the Mariel Boatlift on the Miami Labor Market

David Card (1990). Industrial and Labor Relations Review 43(2), 245-257; author-hosted published copy.

[Identity record](https://davidcard.berkeley.edu/papers/mariel-impact.pdf) | [Inspected source](https://davidcard.berkeley.edu/papers/mariel-impact.pdf)

Roles: question, method. Priority: must_read. Access: full_text.

Sections inspected: Title and abstract, printed p. 245 (PDF p. 2); Opening discussion, printed pp. 245-246; Comparison-city selection paragraph, printed p. 249. Student checked: false.

Version note: The 1989 NBER working paper is not counted as another work.

<a id="evidence-e01"></a>

- **E01** [Abstract, printed p. 245; PDF p. 2](https://davidcard.berkeley.edu/papers/mariel-impact.pdf): Reports little wage/unemployment impact for less-skilled workers.

<a id="evidence-e02"></a>

- **E02** [Opening discussion, printed p. 246; PDF p. 3](https://davidcard.berkeley.edu/papers/mariel-impact.pdf): Describes CPS microdata for 1979-1985.

<a id="evidence-e03"></a>

- **E03** [Comparison-city selection paragraph, printed p. 249; PDF p. 6](https://davidcard.berkeley.edu/papers/mariel-impact.pdf): Explains selection of four comparison cities.


- **Question:** **Authors state:** Mariel's effect on Miami labour-market outcomes. [E01](#evidence-e01)
- **Mechanism:** **Not checked:** Mechanism evidence not examined.
- **Design:** **Authors state:** CPS comparisons across time and cities; assumptions need closer reading. [E02](#evidence-e02) [E03](#evidence-e03)
- **Result:** **Authors state:** Reports little adverse effect on the studied outcomes. [E01](#evidence-e01)
- **Scope:** **Authors state:** Miami; less-skilled workers. [E01](#evidence-e01)
- **Connection:** **Interpretation:** Direct question/design predecessor. [E01](#evidence-e01) [E03](#evidence-e03)
- **Difference:** **Interpretation:** A new setting needs a meaningful boundary condition, not geography alone. [E01](#evidence-e01)

### P02: The Wage Impact of the Marielitos: A Reappraisal

George J. Borjas (2017). ILR Review 70(5); published article abstract.

[Identity record](https://journals.sagepub.com/doi/10.1177/0019793917692945) | [Inspected source](https://journals.sagepub.com/doi/10.1177/0019793917692945)

Roles: question, alternative_explanation. Priority: must_read. Access: abstract_only.

Sections inspected: Publisher abstract. Student checked: false.

Version note: The 2015 NBER working paper 21588 is a predecessor version, not substituted for this abstract. Author-hosted PDF attempts timed out.

<a id="evidence-e04"></a>

- **E04** [Abstract, publisher page](https://journals.sagepub.com/doi/10.1177/0019793917692945): Targets high-school dropouts and reports a 10-30% wage decline.


- **Question:** **Authors state:** Wage impact for workers matching the inflow's low schooling. [E04](#evidence-e04)
- **Mechanism:** **Not checked:** Detailed mechanism tests not inspected.
- **Design:** **Not checked:** Detailed design and sample restrictions not inspected.
- **Result:** **Authors state:** Reports a 10-30% wage decline. [E04](#evidence-e04)
- **Scope:** **Authors state:** Miami high-school dropouts; further restrictions not checked. [E04](#evidence-e04)
- **Connection:** **Interpretation:** A competing reported finding requiring comparable estimands. [E04](#evidence-e04)
- **Difference:** **Interpretation:** Check target populations before treating estimates as contradictory. [E04](#evidence-e04)

### P03: The Labor Market Effects of a Refugee Wave: Synthetic Control Method Meets the Mariel Boatlift

Giovanni Peri; Vasil Yasenov (2017). Author-hosted draft dated June 2, 2017.

[Identity record](https://giovanniperi.ucdavis.edu/uploads/5/6/8/2/56826033/mariel_jun2_app.pdf) | [Inspected source](https://giovanniperi.ucdavis.edu/uploads/5/6/8/2/56826033/mariel_jun2_app.pdf)

Roles: question, method, alternative_explanation. Priority: must_read. Access: full_text.

Sections inspected: Title and abstract, p. 1; Introduction, pp. 2-3. Student checked: false.

Version note: Author's publication page lists the 2019 Journal of Human Resources 54(2), 267-309 successor. That version was not inspected. Its publisher page returned 403.

<a id="evidence-e05"></a>

- **E05** [Abstract, p. 1](https://giovanniperi.ucdavis.edu/uploads/5/6/8/2/56826033/mariel_jun2_app.pdf): Revisits Card; reports no significant wage difference for non-Cuban dropouts and questions small-subsample results.

<a id="evidence-e06"></a>

- **E06** [Introduction, p. 3](https://giovanniperi.ucdavis.edu/uploads/5/6/8/2/56826033/mariel_jun2_app.pdf): Motivates systematic control construction and inference allowing city shocks.


- **Question:** **Authors state:** Reassess Mariel labour-market effects. [E05](#evidence-e05)
- **Mechanism:** **Not checked:** Mechanism identification not checked.
- **Design:** **Authors state:** Synthetic control motivated by comparison selection and inference concerns. [E06](#evidence-e06)
- **Result:** **Authors state:** Reports no significant wage difference for non-Cuban dropouts. [E05](#evidence-e05)
- **Scope:** **Authors state:** Mariel; non-Cuban high-school dropouts. [E05](#evidence-e05)
- **Connection:** **Interpretation:** A prior methodological revisit, not a blank slate. [E06](#evidence-e06)
- **Difference:** **Interpretation:** Using synthetic control alone does not establish an addition. [E06](#evidence-e06)

## Connections

- P03 -> P01 (Observed citation relationship): Explicitly revisits the earlier study. [E05](#evidence-e05)
- P02 -> P03 (Inferred intellectual connection): Reported results differ; population/design comparability must be read before adjudicating. [E04](#evidence-e04) [E05](#evidence-e05)

## Priority Reading Tasks

1. **P01** Read: Comparison-city selection, pp. 249 onward; relevant tables and conclusion. Question: What is compared and which counterfactual assumptions carry the interpretation? Decision: Specify the proposed project's estimand and counterfactual.
2. **P02** Read: Obtain the full published article legally; read sample construction and design. Question: Which population, comparison group and time window generate the estimate? Decision: Determine whether the apparent disagreement is about the same target effect.
3. **P03** Read: Read data/samples and inference sections; check published successor. Question: What existing advance does the proposed use of synthetic control merely repeat? Decision: Retain, change or abandon the tentative methodological contribution.

## Coverage And Limits

- Intentionally restricted to three familiar works. No comprehensive recent-working-paper search, exclusion audit or missing-predecessor challenge was completed.
- NBER landing pages and public PDF links returned 403 through the search tool. Legal author-hosted copies and a publisher abstract were used instead; no access control was bypassed.
- Borjas is abstract-only. Detailed sample restrictions, identifying assumptions and robustness results were not checked.
- Only the named sections of the other papers were inspected, not entire texts, appendices or replication code. No independent econometric appraisal is claimed.
- The Peri-Yasenov text inspected is the June 2, 2017 author draft, not the 2019 published version. Student verification is outstanding for all rows.
