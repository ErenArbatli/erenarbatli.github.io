# Worked Example: Immigration, Wages And Comparison Design

This is an intentionally small teaching demonstration using published research. It is not a student's confidential proposal, an exhaustive literature search, or a claim that a new immigration project is publishable.

## Hypothetical Student Input

"I want to study how a sudden refugee inflow affects the wages of less-skilled incumbent workers. I am considering comparing the receiving labour market with similar places before and after the inflow. I have not chosen a setting or obtained data. I wonder whether a synthetic control would strengthen the comparison. My main uncertainty is whether this would add anything to existing research rather than simply repeat it."

## Baseline And Interpretation

- Question supplied: wage response to a sudden inflow, focused on less-skilled incumbents.
- Mechanism conjecture: labour-market competition; not yet distinguished from demand or adjustment channels.
- Design supplied: comparative before/after analysis, potentially synthetic control. No identifying assumptions have been justified.
- Proposed contribution: not established. Choosing another setting or using a named method is insufficient by itself.
- Assistant interpretation: differences in sample definitions and comparison construction are important reading questions. These are not findings about a proposed project.
- Unknowns: setting, data, treatment timing, population, estimand, design credibility and feasible distinctive contribution.

## Demonstration Scope

Searches used ordinary web search with concept-led follow-ups and primary-source opens, not a dedicated semantic index or an authenticated scholarly database. Three deliberately familiar works were compared. The complete search budget, multi-branch coverage and novelty audit of a normal first pass were not attempted. No external service received an unpublished draft.

Only the locations in the evidence cards were inspected. None of the papers has been marked student-checked. The author-hosted Peri-Yasenov draft is dated June 2, 2017; the published successor is identified separately, not silently substituted.
