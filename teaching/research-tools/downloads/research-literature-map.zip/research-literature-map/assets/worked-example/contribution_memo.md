# Worked Example: Contribution Memo

## What This First Pass Changes

The hypothetical idea is not yet a contribution. A familiar question plus synthetic control is not enough: an existing study explicitly motivates that methodological revisit ([P03, introduction p. 3](https://giovanniperi.ucdavis.edu/uploads/5/6/8/2/56826033/mariel_jun2_app.pdf)). Before proposing another application, the student needs a meaningful inferential or economic distinction.

## AI-Assisted Provisional Wording

"I propose to examine wage adjustment after a sudden refugee inflow. My next step is to establish whether the proposed setting or data would let me resolve a specific comparison, measurement or adjustment question that existing studies cannot resolve. No such distinction has yet been verified. I will first compare the target populations, counterfactual construction and uncertainty in the closest studies, and use that comparison to decide whether to continue or resize the project."

This is a statement of research direction, not a ready-to-submit contribution paragraph. The project has no chosen data, justified design or established result. Abstract-only comparison cannot settle the debate.

## Closed-Corpus Challenge

Strongest objection: the proposed methodological label is already present in P03. Required response: identify a consequential new inference, mechanism test or boundary condition and show which predecessor does not establish it. Do not describe another setting as inherently novel or assume synthetic control always improves identification.

## Separate Open Discovery Challenge

Not completed in this intentionally restricted demonstration. Before making a contribution claim, search related refugee/labour-adjustment work, recent working papers and methodological comparisons beyond these three seeds. Unsuccessful searches would still not prove novelty.

## Student Task And Supervision

Read the three priority items in `literature_map.md`. Correct the population/design comparisons from the actual text. Write 100-150 words answering what is known, what changes, what that would enable and why meaningful.

Supervision question: "What concrete feature of a feasible setting or dataset could let me answer an economically meaningful question not settled by these comparisons?"

Next project action: make a one-page feasibility note specifying a candidate population, outcome, comparison and the data needed to distinguish the proposed contribution. The matrix does not establish that those data exist.
