# Search Log: Worked example: refugee inflows, wages and comparison design

Search mode: Ordinary web search with concept-led follow-ups and primary-source opens; no vector index or authenticated database search

## Search 1

- Date: 2026-11-08
- Tool: web search; not NBER's internal search
- Route: economics
- Exact query / source section: site.nber.org Mariel Boatlift Card 1990 Borjas 2017 Peri Yasenov synthetic control
- Seeds: none
- Matrix papers found: P01, P02, P03
- Follow-up decision: Found familiar related records; open primary sources and distinguish versions.

## Search 2

- Date: 2026-11-08
- Tool: web search
- Route: concept
- Exact query / source section: site.davidcard.berkeley.edu papers Mariel Boatlift 1990 pdf
- Seeds: P01
- Matrix papers found: P01
- Follow-up decision: Use the author-hosted published copy; do not depend on inaccessible NBER landing pages.

## Search 3

- Date: 2026-11-08
- Tool: web search
- Route: economics
- Exact query / source section: site.nber.org w21588 Mariel Boatlift low skilled wages Borjas
- Seeds: P02
- Matrix papers found: P02
- Follow-up decision: Identify working-paper predecessor; seek published source rather than mix versions.

## Search 4

- Date: 2026-11-08
- Tool: web search
- Route: concept
- Exact query / source section: "The Labor Market Effects of a Refugee Wave" Peri Yasenov pdf 2019
- Seeds: P03
- Matrix papers found: P03
- Follow-up decision: Publication and working-paper records differ in dates/titles; retain exact inspected version.

## Search 5

- Date: 2026-11-08
- Tool: web search
- Route: concept
- Exact query / source section: "The Wage Impact of the Marielitos" Borjas pdf July 2016
- Seeds: P02
- Matrix papers found: P02
- Follow-up decision: Author-hosted PDF opens timed out; use publisher abstract and leave detailed design unknown.

## Search 6

- Date: 2026-11-08
- Tool: web search
- Route: concept
- Exact query / source section: Peri Yasenov Mariel boatlift site:docs.iza.org pdf
- Seeds: P03
- Matrix papers found: P03
- Follow-up decision: Found another working-paper version; do not count it as an independent paper.

## Search 7

- Date: 2026-11-08
- Tool: web search
- Route: concept
- Exact query / source section: Peri Yasenov "Refugee Wave" site:giovanniperi.ucdavis.edu filetype:pdf
- Seeds: P03
- Matrix papers found: P03
- Follow-up decision: Found accessible June 2, 2017 author text; inspect abstract and introduction pp. 2-3.

## Candidate Decisions

- **included** [Card (1990)](https://davidcard.berkeley.edu/papers/mariel-impact.pdf): Foundational question/design predecessor; selected passages inspected.
- **included** [Borjas (2017)](https://journals.sagepub.com/doi/10.1177/0019793917692945): Competing reported finding; abstract-only comparison explicitly limited.
- **included** [Peri and Yasenov, June 2, 2017 draft](https://giovanniperi.ucdavis.edu/uploads/5/6/8/2/56826033/mariel_jun2_app.pdf): Prior methodological revisit; limited text inspected.
- **excluded** [Peri and Yasenov, May 10, 2016 draft](https://giovanniperi.ucdavis.edu/uploads/5/6/8/2/56826033/mariel_may_10_2016.pdf): Earlier version of P03, not a distinct intellectual work; not inspected.

## Unavailable Routes And Other Limits

- Intentionally restricted to three familiar works. No comprehensive recent-working-paper search, exclusion audit or missing-predecessor challenge was completed.
- NBER landing pages and public PDF links returned 403 through the search tool. Legal author-hosted copies and a publisher abstract were used instead; no access control was bypassed.
- Borjas is abstract-only. Detailed sample restrictions, identifying assumptions and robustness results were not checked.
- Only the named sections of the other papers were inspected, not entire texts, appendices or replication code. No independent econometric appraisal is claimed.
- The Peri-Yasenov text inspected is the June 2, 2017 author draft, not the 2019 published version. Student verification is outstanding for all rows.
