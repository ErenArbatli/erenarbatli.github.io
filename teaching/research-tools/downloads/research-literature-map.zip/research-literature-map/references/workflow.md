# Search And Comparison Workflow

## 1. Frame A Searchable Project

Extract a short baseline without improving the project's claimed contribution. Quote or reference the student's source and separate inference from supplied facts. If a student says "school quality and house prices", ask what outcome/comparison interests them, or run an explicitly exploratory map. Do not invent a causal instrument or data access.

Make four query families, usually with two formulations each:

| Family | Search for | Example for a generic political-economy project |
| --- | --- | --- |
| Question | Outcome and substantive relationship | historical assistance and persistent party support |
| Mechanism | Underlying economic/behavioural channel | intergenerational political loyalty; gratitude; socialisation |
| Design/model | Identification problem or strategic structure | historical exposure and descendant outcomes; reputation after a regime break |
| Adjacent concepts | Different terminology/applications | organisational memory; identity persistence; political attachment |

These examples illustrate query reformulation, not permission to disclose a student's distinctive hypothesis. Search generalised concepts unless disclosure is authorised. Do not upload drafts to third-party extraction tools by default.

## 2. Run A Bounded, Adaptive Search

Use available tools rather than assuming particular subscriptions or APIs. A useful initial budget is 8-12 query calls, followed by targeted source opens, to screen about 10-15 distinct works. The budget is flexible: stop earlier when the question is still unclear, sources are inaccessible or the student has enough to read. Do not pad a matrix to meet a numeric target.

### Discovery Routes

- **Economics-indexed:** use an actual available EconLit, IDEAS/RePEc, JEL or scholarly search interface; otherwise label a site-restricted web search accurately. Search without geographic/method restrictions at least once to avoid hiding conceptual predecessors.
- **Meaning-led expansion:** reformulate the question/mechanism, follow terminology found in relevant abstracts, and investigate at least one alternative explanation or contrary result. A real semantic-search connector may improve retrieval but is optional. Ordinary web search plus LLM reformulation is not an embedding similarity service.
- **Citation tracing:** use multiple seeds representing distinct branches. Backward links come from an inspected bibliography; forward links require an observed citing record or reference. If that cannot be checked, call the item a related-work lead, not a verified citation edge. Citation counts are not relevance or quality scores.
- **Recent work:** look for working papers, author pages and series relevant to the field. Record the actual date; do not silently impose a publication-only filter. Check a working paper against its published successor where identifiable.

After a small batch, explain a concrete decision: "The results use 'political socialisation', so I will test that term" or "These papers share a setting but not the question; next I will trace the mechanism branch." Record this decision in the log. Do not keep repeating keyword permutations that return no new branch.

Record failed attempts and routes unavailable through current tools. If access is blocked, use a legal author/repository copy, ask for a PDF only when necessary, or retain an abstract-only candidate. Do not invent success, bypass a paywall or ask the student for credentials.

## 3. Screen And Deduplicate

Use overlapping labels: `question`, `mechanism`, `method`, `alternative_explanation`, `background`, `uncertain`. Add a short rationale and priority rather than an opaque relevance score. Include serious competitors, not just papers that flatter the contribution. A null result can be relevant.

Link versions as one intellectual work. Use author/title/DOI or series number to resolve identity. Compare the version actually inspected; if a journal version is inaccessible, cite the working-paper version and identify the published successor without pretending to have read it. Never combine a working-paper result and a published locator without checking both.

Keep a compact candidate ledger, including excluded/deferred items and reasons. Sample a few rejected items from unfamiliar terminology to test false negatives. Known-paper retrieval is a diagnostic, not proof of completeness. If known papers are missed, revisit vocabulary rather than declaring the literature small.

## 4. Verify And Extract At Claim Level

Verify bibliographic identity separately from interpretation. Prefer a publisher/DOI record, working-paper series, institutional repository or author-hosted text. If conflicting dates or titles cannot be reconciled, retain the conflict explicitly.

For close comparisons read the introduction and the precise design, results, model, proposition or appendix sections needed. For long PDFs, extract/read selected page ranges in small batches; inspect page images where equations, figures or tables are ambiguous. Record what was actually inspected and both printed/PDF pagination when useful. A failed download or unreadable scan does not count as reading.

For each comparison preserve:

- Source URL, exact version and specific location.
- A short paraphrase of supporting evidence; brief quotation only when necessary and within source limits.
- Whether the cell reports an author's claim, your interpretation, missing inspection or absence from an inspected section.
- Whether a student has explicitly checked it. Never infer human verification from silence or a supplied PDF.

Abstracts can support the question and headline author-reported result. Do not extract unmentioned sample restrictions, assumptions or mathematical conditions from them. `Not checked` differs from `not reported in the abstract`, which differs from `not reported anywhere in the paper`.

### Empirical Comparisons

Check unit/population, outcome, treatment/estimand, identifying variation, comparison group, assumptions, timing, precision and scope. Do not infer parallel trends, exclusion restrictions or mechanism identification from a design label. Do not describe a bundled intervention as separating components unless design or additional analysis establishes that separation. Absence of statistical significance is not proof of no economically meaningful effect.

Separate "the authors interpret this as causal" from "we have assessed the credibility of this causal claim". The latter requires reading and judgement. Improvements in one dimension can narrow scope or require stronger assumptions elsewhere.

### Theory Comparisons

Check players, information, timing, actions, payoffs/technology, equilibrium concept, parameter restrictions and propositions. Different nouns can hide the same strategic structure. Ask whether an existing model nests the proposed result, or the proposal nests the benchmark. Treat equivalence, non-equivalence and proof validity as unresolved unless the mathematics has actually been inspected and worked through. Do not exclude empirical research that documents the mechanism simply because the proposal is theoretical.

## 5. Explain Connections And Consequences

Use a short edge list or a simple text diagram; do not spend the student's research time on elaborate graphics. Each edge has a type, rationale and supporting source IDs. Examples:

- `P03 -> P01: authors explicitly revisit the earlier design [E07]`.
- `P02 -- P04: AI-inferred shared mechanism, different application [E03, E09]`.

A citation link is an observed bibliographic relationship. A shared-mechanism edge is a reasoned interpretation. Keep them distinct. Conflicting findings may reflect different estimands, samples, models or precision rather than one paper being wrong.

For each closest paper answer: what is established; what changes; what new inference/result might follow; why meaningful. If the third answer is unknown, label a potential distinction rather than claiming a contribution. A different setting matters when it reveals a boundary condition, tests a mechanism or enables a previously unavailable comparison, not because it has a different name.

## 6. Challenge, Read And Revise

Run two separate tasks:

1. **Closed-corpus challenge:** use only inspected evidence to identify the strongest predecessor, overclaim, alternative interpretation and needed test/proposition. Cite exact locations. If evidence is insufficient, say what to inspect rather than inventing a criticism.
2. **Open discovery challenge:** search for one or two missing predecessors using the most threatening alternative terminology. Newly found candidates remain candidates until checked.

Invite the student to draft 100-150 words. If an immediate draft is useful, label it "AI-assisted provisional wording" and tie its literature claims to evidence IDs. No unqualified "first", "unique", "proves", or "no prior work" on the basis of search absence. Do not pretend a proposed design or expected result is already established.

Choose three priority readings with locations, a question to resolve and the project decision each could change. Ask the student to confirm/correct the comparisons. Finish with one concrete supervision question and one next project action. The output is a living research map, not a formal systematic review or a substitute for supervision.
