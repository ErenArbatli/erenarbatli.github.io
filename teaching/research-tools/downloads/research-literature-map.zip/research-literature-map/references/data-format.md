# Structured Record Format

This format is for the assistant, not a form the student must complete. Start with `assets/starter.json` and replace its demonstration date with the actual execution date. The renderer uses Python's standard library; it makes no network calls. It checks link syntax and provenance structure, not whether sources are genuine or interpretations are correct.

## Top Level

- `project`: `title`, `description`, ISO `date` (`YYYY-MM-DD`), `search_mode`, `limitations` (list of strings). Explain actual capabilities in `search_mode`, such as "web search with concept expansion; no vector index" or "supplied sources only".
- `papers`: priority comparison records, defined below. Candidates without checked identity stay in `candidates`, not the comparison matrix.
- `searches`: actual search records; may be empty for supplied-sources-only work.
- `candidates`: screened/deferred/excluded records, including items not yet ready for the matrix.
- `connections`: observed citation links or inferred intellectual relationships.
- `reading_tasks`: short targeted follow-ups.

## Paper

Required fields:

```json
{
  "id": "P01",
  "title": "Exact title from primary record",
  "authors": ["Author One", "Author Two"],
  "year": 2020,
  "version": "Working paper, revision dated 2020-06",
  "identity_url": "https://institution.example/paper-record",
  "source_url": "https://institution.example/inspected-version.pdf",
  "identity_checked": true,
  "access": "full_text",
  "read_sections": ["Introduction, printed pp. 1-3"],
  "student_checked": false,
  "roles": ["question", "mechanism"],
  "priority": "must_read",
  "version_note": "Published successor exists but was not inspected.",
  "evidence": [
    {"id": "E01", "location": "Introduction, p. 2", "note": "Brief supporting paraphrase."}
  ],
  "claims": {
    "question": {"text": "Precise question.", "basis": "source", "evidence_ids": ["E01"]},
    "mechanism": {"text": "Not checked.", "basis": "not_checked", "evidence_ids": []},
    "design": {"text": "Not checked.", "basis": "not_checked", "evidence_ids": []},
    "result": {"text": "Not checked.", "basis": "not_checked", "evidence_ids": []},
    "scope": {"text": "Not checked.", "basis": "not_checked", "evidence_ids": []},
    "connection": {"text": "Potential conceptual predecessor.", "basis": "interpretation", "evidence_ids": ["E01"]},
    "difference": {"text": "Not checked.", "basis": "not_checked", "evidence_ids": []}
  }
}
```

The example URLs illustrate shape, not real sources. Replace with inspected sources; do not copy this record as a verified paper.

`access`: `metadata_only`, `abstract_only`, `full_text`. `full_text` means the text is accessible, **not** that the whole paper was read. `read_sections` is the actual reading record. For abstract-only reading every evidence locator must begin with `Abstract`; no unseen section can be cited. Metadata-only rows have no textual evidence or source claims.

`roles`: one or more of `question`, `mechanism`, `method`, `alternative_explanation`, `background`, `uncertain`. `priority`: `must_read`, `useful`, `background`, `uncertain`.

Each of the seven `claims` fields is required; unknowns are explicit. `basis`:

- `source`: author-reported information, with at least one evidence ID from this paper.
- `interpretation`: assistant/researcher judgement, linked to evidence where available. Unsupported interpretations remain conjectures, not verified novelty claims.
- `not_checked`: material not inspected/unavailable. No evidence IDs; explain the gap in `text`.
- `not_reported`: absence from a specified inspected section, with evidence IDs documenting the section searched. Do not generalise to an entire paper.

Evidence IDs are globally unique; locators and notes are nonempty. Claims can only reference their own paper's evidence. Identity and source links must be HTTP(S) URLs or absolute local paths. The script does not visit URLs or check access. `identity_checked` means the assistant actually resolved identity; `student_checked` defaults false and changes only following explicit student confirmation. Keep substantive student corrections in the records and preserve the previous version.

## Other Records

Search:

```json
{"date":"2026-11-08","tool":"actual tool/interface","route":"concept","query":"exact query or inspected citation section","seed_ids":[],"paper_ids":["P01"],"decision":"Why this result changed the next step."}
```

`route`: `concept`, `economics`, `backward`, `forward`, `recent`, `novelty`, `user_seed`. Put unavailable routes in project limitations; do not record them as completed searches. A discovered lead need not have a `paper_id` until included in the matrix. Exact leads can be listed in the corresponding candidate record.

Candidate:

```json
{"title":"Candidate title or unresolved lead","url":"https://example.org/record","disposition":"deferred","reason":"Abstract suggests a related mechanism; full comparison not yet checked."}
```

`disposition`: `included`, `deferred`, `excluded`, `unverified`. `url` may be empty for an unresolved lead, never invented. If there are no checked papers, keep `papers` and `reading_tasks` empty; put proposed candidate-level readings and unrun searches in a separate `query_pack.md`. Render the records anyway so the absence of checked comparisons is visible.

Connection:

```json
{"from":"P02","to":"P01","kind":"inferred","description":"Shared mechanism in different applications.","evidence_ids":["E01","E02"]}
```

`kind`: `citation` or `inferred`. A `citation` needs evidence in the **citing** paper explicitly showing the relationship. An `inferred` edge needs inspected evidence from **both** papers. Use at least two distinct papers; no self-links. These rules check provenance structure, not whether an edge's interpretation is right.

Reading task:

```json
{"paper_id":"P01","sections":"Design section and relevant appendix","question":"Which assumption carries the comparison?","decision":"Keep or resize the proposed identification strategy."}
```

## Run

From the skill folder:

```bash
python3 scripts/render_map.py /path/to/literature_map.json --check
python3 scripts/render_map.py /path/to/literature_map.json --out /path/to/new-output-folder
python3 -m unittest discover -s tests
```

The renderer refuses to overwrite any of its three output files. For revisions choose a new output directory, keeping earlier files and student notes. It creates `literature_map.md`, `comparison_matrix.csv` (UTF-8 with BOM) and `search_log.md`. Files never make external requests. Spreadsheet cells beginning with formula-trigger characters are escaped on CSV export.
